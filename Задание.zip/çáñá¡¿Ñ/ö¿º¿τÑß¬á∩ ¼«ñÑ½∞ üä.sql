CREATE DATABASE okchtaPark

USE okchtaPark


CREATE TABLE Employees
(
ID_employees INT primary key identity,
codeEmployees INT,
positionEmployees NVARCHAR(30),
lastName NVARCHAR(100),
firstName NVARCHAR(50),
patronymic NVARCHAR(70),
login NVARCHAR(50),
password NVARCHAR(50),
lastEntry DATETIME,
typeEntry NVARCHAR(30),
);

CREATE TABLE Services
(
ID_services int primary key identity,
numberServices int,
nameServices nvarchar(100),
codeServices nvarchar(20),
priceServices money,
);

CREATE TABLE Client
(
ID_Clients int primary key identity,
LastName nvarchar(100),
FirstName nvarchar(50),
Patronymic nvarchar(70),
codeClients int,
seriesPass int,
numberPass int,
dataBirthday date,
indexClient int,
city nvarchar(50),
street nvarchar(50),
home int,
numberHome int,
email nvarchar(60),
passwordClient nvarchar(20),
);

CREATE TABLE Orders
(
ID_order int primary key identity,
codeOrder int,
dataOrder date,
timeOrder time,
codeClients int,
services text,
status nvarchar(40),
dataClosing date,
timeRental int,
ID_clientss int,
foreign key (ID_clientss) references Client(ID_Clients),
);

CREATE TABLE HistoryEnter
(
ID_HistoryEnter INT primary key identity,
loginHistoryEnter nvarchar(100),
passHistoryEnter nvarchar(100)
);

CREATE TABLE Park
(
ID_Park int primary key identity,
employees_ID int,
client_ID int,
services_ID int,
historyEnters_ID int,
foreign key (employees_ID) references Employees(ID_employees),
foreign key (client_ID) references Client(ID_Clients),
foreign key (services_ID) references Services(ID_services),
foreign key (historyEnters_ID) references HistoryEnter(ID_HistoryEnter)
);