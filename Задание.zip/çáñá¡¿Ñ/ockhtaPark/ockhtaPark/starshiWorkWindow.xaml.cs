﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для starshiWorkWindow.xaml
    /// </summary>
    public partial class starshiWorkWindow : Window
    {
        public starshiWorkWindow()
        {
            InitializeComponent();
        }
        // переход в окно "Клиенты"
        private void clientsWindowBtn_Click(object sender, RoutedEventArgs e)
        {
            clientWindow clientWindow = new clientWindow();
            clientWindow.Show();
            this.Close();
        }
        // переход в окно "Услуги"
        private void uslugiWindowBtn_Click(object sender, RoutedEventArgs e)
        {
            uslugiWindow uslugiWindow = new uslugiWindow();
            uslugiWindow.Show();
            this.Close();
        }
        // выход в окно "Авторизация"
        private void exitToAvtorizationOneBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        // переход в окно "Заказы"
        private void zakazWindowOneBtn_Click(object sender, RoutedEventArgs e)
        {
            addZakazWindow addZakazWindow = new addZakazWindow();
            addZakazWindow.Show();
            this.Close();
        }
    }
}
