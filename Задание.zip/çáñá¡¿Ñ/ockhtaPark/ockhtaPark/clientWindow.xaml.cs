﻿using ockhtaPark.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для clientWindow.xaml
    /// </summary>
    public partial class clientWindow : Window
    {
        public clientWindow()
        {
            InitializeComponent();
            clientDG.ItemsSource = okchtaParkEntities.Client.ToList();
        }

        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();

        private void exitToMenuStarhiWorkOneBtn_Click(object sender, RoutedEventArgs e)
        {
            starshiWorkWindow starshiWorkWindow = new starshiWorkWindow();
            starshiWorkWindow.Show();
            this.Close();
        }
        // поиск клиента
        private void searchClientTB_SelectionChanged(object sender, RoutedEventArgs e)
        {
            model.okchtaParkEntities db = new model.okchtaParkEntities();

            string search = searchClientTB.Text;

            if (searchClientTB.Text != null)
            {
                var query = (from clt in db.Client
                             where clt.LastName.ToString().Contains(search)
                             select clt).ToList();
                clientDG.ItemsSource = query;
            }
        }

        private void addClientsWindowBtn_Click(object sender, RoutedEventArgs e)
        {
            addClientWindow addClientWindow = new addClientWindow();
            addClientWindow.Show();
            this.Close();
        }
    }
}
