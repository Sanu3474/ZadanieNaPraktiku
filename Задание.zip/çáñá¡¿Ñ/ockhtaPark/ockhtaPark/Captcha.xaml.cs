﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для Captcha.xaml
    /// </summary>
    public partial class Captcha : Window
    {
        String pwd;
        int error = 0;
        public Captcha()
        {
            InitializeComponent();
            // генерация капчи
            String allowchar = " ";
            allowchar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            allowchar += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";
            allowchar += "1,2,3,4,5,6,7,8,9,0";
            char[] a = { ',' };
            String[] ar = allowchar.Split(a);
            pwd = "";
            string temp = " ";
            Random r = new Random();
            Random capR = new Random();
            string src = "\\capch\\" + "C" + capR.Next(1, 5) + ".png";
            var uriSource = new Uri(src, UriKind.RelativeOrAbsolute);
            Img.Source = new BitmapImage(uriSource);
            for (int i = 0; i < 5; i++)
            {
                temp = ar[(r.Next(0, ar.Length))];
                pwd += temp;
            }
            CapBox.Content = pwd;
        }

        int not = 15;
        System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
        // блокировка при неверном вводе капчи
        private void timerTick(object sender, EventArgs e)
        {
            if (not == 0)
            {
                this.IsEnabled = true;
                MessageBox.Show("Можете вводить captcha");
                timer.Stop();
                error = 0;
                not = 15;
            }
            else
            {
                not--;
            }
        }
        // проверка капчи
        private void provCaptBtn_Click(object sender, RoutedEventArgs e)
        {
            if (EnterCap.Text == pwd)
            {
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Не верно");
                error++;
                if (error == 3)
                {
                    this.IsEnabled = false;
                    EnterCap.Clear();
                    MessageBox.Show("Слишком много попыток, подождите", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    timer.Tick += new EventHandler(timerTick);
                    timer.Interval = new TimeSpan(0, 0, 1);
                    timer.Start();
                }
            }
        }
        // обновление капчи
        private void obnovCaptBtn_Click(object sender, RoutedEventArgs e)
        {
            String allowchar = " ";
            allowchar = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
            allowchar += "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,y,z";
            allowchar += "1,2,3,4,5,6,7,8,9,0";
            char[] a = { ',' };
            String[] ar = allowchar.Split(a);
            pwd = "";
            string temp = " ";
            Random r = new Random();
            Random capR = new Random();
            string src = "\\capch\\" + "C" + capR.Next(1, 5) + ".png";
            var uriSource = new Uri(src, UriKind.RelativeOrAbsolute);
            Img.Source = new BitmapImage(uriSource);
            for (int i = 0; i < 5; i++)
            {
                temp = ar[(r.Next(0, ar.Length))];
                pwd += temp;
            }
            CapBox.Content = pwd;
        }
    }
}
