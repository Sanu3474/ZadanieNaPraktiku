﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для adminMenuWindow.xaml
    /// </summary>
    public partial class adminMenuWindow : Window
    {
        public adminMenuWindow()
        {
            InitializeComponent();
        }
        // переход в окно "Заказ"
        private void zakazBtn_Click(object sender, RoutedEventArgs e)
        {
            zakazWindow zakazWindow = new zakazWindow();
            zakazWindow.Show();
            this.Close();
        }
        // переход в окно "История входа"
        private void historyEnterBtn_Click(object sender, RoutedEventArgs e)
        {
            historyEnterWindow historyEnterWindow = new historyEnterWindow();
            historyEnterWindow.Show();
            this.Close();
        }
        // выход из ИТ
        private void exitToAvtorizationOneBtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
