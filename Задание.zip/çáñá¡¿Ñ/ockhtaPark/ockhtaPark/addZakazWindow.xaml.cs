﻿using ockhtaPark.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для addZakazWindow.xaml
    /// </summary>
    public partial class addZakazWindow : Window
    {
        public addZakazWindow()
        {
            InitializeComponent();
            DataContext = orders;
        }
        // привязка бд к окну
        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();
        Orders orders = new Orders();

        private void addZakazBtn_Click(object sender, RoutedEventArgs e)
        {
            // проверка на корректность ввода
            try
            {
                if (codeOrderTB.Text == "" || dataOrderTB.Text == "" || timeOrderTB.Text == "" || codeClientsTB.Text == "" ||
                    servicesTB.Text == "" || statusTB.Text == "" || dataClosingTB.Text == "" || timeRentalTB.Text == "" ||
                    ID_clientssTB.Text == "")
                {
                    MessageBox.Show("Есть пустые поля, их необходимо заполнить");
                }
                else
                {
                    // добавление данных в БД и переход в окно
                    okchtaParkEntities.Orders.Add(orders);
                    okchtaParkEntities.SaveChanges();

                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Данные введены некорректно");
            }
        }
    }
}
