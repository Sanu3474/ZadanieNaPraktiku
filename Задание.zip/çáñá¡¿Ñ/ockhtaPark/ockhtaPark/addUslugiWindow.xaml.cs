﻿using ockhtaPark.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для addUslugiWindow.xaml
    /// </summary>
    public partial class addUslugiWindow : Window
    {
        public addUslugiWindow()
        {
            InitializeComponent();
            DataContext = services;
        }
        // привязка бд к окну
        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();
        Services services = new Services();

        private void addUslugBtn_Click(object sender, RoutedEventArgs e)
        {
            // проверка на корректность ввода
            try
            {
                if (codeServTB.Text == "" || nameServTB.Text == "" || numbServTB.Text == "" || priceServTB.Text == "")
                {
                    MessageBox.Show("Есть пустые поля, их необходимо заполнить");
                }
                else
                {
                    // добавление данных в БД и переход в окно
                    okchtaParkEntities.Services.Add(services);
                    okchtaParkEntities.SaveChanges();
                    uslugiWindow uslugiWindow = new uslugiWindow();
                    uslugiWindow.Show();
                    this.Close();
                }
            }
            catch 
            {
                MessageBox.Show("Данные введены некорректно");
            }
        }
    }
}
