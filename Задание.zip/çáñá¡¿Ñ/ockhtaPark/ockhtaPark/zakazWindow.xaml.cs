﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ockhtaPark.model;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для zakazWindow.xaml
    /// </summary>
    public partial class zakazWindow : Window
    {
        public zakazWindow()
        {
            InitializeComponent();
            zakazDG.ItemsSource = okchtaParkEntities.Orders.ToList();
        }

        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();

        private void exitToMenuAdminWindowTwo_Click(object sender, RoutedEventArgs e)
        {
            adminMenuWindow adminMenuWindow = new adminMenuWindow();
            adminMenuWindow.Show();
            this.Close();
        }
    }
}
