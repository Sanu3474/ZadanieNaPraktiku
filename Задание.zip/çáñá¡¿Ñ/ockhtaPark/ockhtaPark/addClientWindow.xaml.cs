﻿using ockhtaPark.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для addClientWindow.xaml
    /// </summary>
    public partial class addClientWindow : Window
    {
        public addClientWindow()
        {
            InitializeComponent();
            DataContext = client;
        }
        // привязка бд к окну
        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();
        Client client = new Client();

        private void addclientBtn_Click(object sender, RoutedEventArgs e)
        {
            // проверка на корректность ввода
            try
            {
                if (LastNameTB.Text == "" || FirstNameTB.Text == "" || PatronymicTB.Text == "" ||
                    codeClientsTB.Text == "" || seriesPassTB.Text == "" || numberPassTB.Text == "" ||
                    dataBirthdayTB.Text == "" || indexClientTB.Text == "" || cityTB.Text == "" ||
                    streetTB.Text == "" || homeTB.Text == "" || numberHomeTB.Text == "" || emailTB.Text == "")
                {
                    MessageBox.Show("Есть пустые строки");
                }
                else
                {
                    // добавление данных в БД и переход в окно
                    okchtaParkEntities.Client.Add(client);
                    okchtaParkEntities.SaveChanges();
                    clientWindow clientWindow = new clientWindow();
                    clientWindow.Show();
                    this.Close();
                }
            }
            catch
            {
                MessageBox.Show("Данные введены некорректно");
            }
        }
    }
}
