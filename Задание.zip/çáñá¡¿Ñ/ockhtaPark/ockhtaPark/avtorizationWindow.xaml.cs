﻿using ockhtaPark.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = historyEnter;
        }
        int a = 0;
        // привязка базы данных
        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();
        HistoryEnter historyEnter = new HistoryEnter();
        private void avtorizationBtn_Click(object sender, RoutedEventArgs e)
        {
            // сверка логина и пароля с данными из БД
            okchtaParkEntities = new model.okchtaParkEntities();
            var prov = okchtaParkEntities.Employees.FirstOrDefault(x => x.login == loginTB.Text &&
            (x.password == hidePassTB.Password || x.password == vissPassTB.Text));
            try
            {

                if (prov != null && okchtaParkEntities.Employees.Any(x => x.positionEmployees == "Администратор" && x.login == loginTB.Text))
                {
                    // переход в меню администатора
                    okchtaParkEntities.HistoryEnter.Add(historyEnter);
                    okchtaParkEntities.SaveChanges();
                    adminMenuWindow adminMenuWindow = new adminMenuWindow();
                    adminMenuWindow.Show();
                    this.Close();
                }
                else
                {
                    if (prov != null && okchtaParkEntities.Employees.Any(x => x.positionEmployees == "Старший смены" && x.login == loginTB.Text))
                    {
                        // переход в меню старшего смены
                        okchtaParkEntities.HistoryEnter.Add(historyEnter);
                        okchtaParkEntities.SaveChanges();
                        starshiWorkWindow starshiWorkWindow = new starshiWorkWindow();
                        starshiWorkWindow.Show();
                        this.Close();
                    }
                    else
                    {
                        if (prov != null && okchtaParkEntities.Employees.Any(x => x.positionEmployees == "Продавец" && x.login == loginTB.Text))
                        {
                            // переход в меню продавца
                            okchtaParkEntities.HistoryEnter.Add(historyEnter);
                            okchtaParkEntities.SaveChanges();
                            workerMenuWindow workerMenuWindow = new workerMenuWindow();
                            workerMenuWindow.Show();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Данные введены неверно");
                            a = a + 1;

                            if (a > 1)
                            {
                                // вызов капчи
                                Captcha captcha = new Captcha();
                                captcha.ShowDialog();
                            }
                            else
                            {

                            }
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }

        private void exitToWindowBtn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        // Маска для пароля
        private void vissPass_Click(object sender, RoutedEventArgs e)
        {
            var checkBox = sender as CheckBox;
            if (checkBox.IsChecked.Value)
            {
                vissPassTB.Text = hidePassTB.Password; // скопируем в TextBox из PasswordBox
                vissPassTB.Visibility = Visibility.Visible; // TextBox - отобразить
                hidePassTB.Visibility = Visibility.Hidden; // PasswordBox - скрыть
            }
            else
            {
                hidePassTB.Password = vissPassTB.Text; // скопируем в PasswordBox из TextBox 
                vissPassTB.Visibility = Visibility.Hidden; // TextBox - скрыть
                hidePassTB.Visibility = Visibility.Visible; // PasswordBox - отобразить
            }
        }
    }
}
