﻿using ockhtaPark.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ockhtaPark
{
    /// <summary>
    /// Логика взаимодействия для uslugiWindow.xaml
    /// </summary>
    public partial class uslugiWindow : Window
    {
        public uslugiWindow()
        {
            InitializeComponent();
            servicesDG.ItemsSource = okchtaParkEntities.Services.ToList();
        }

        okchtaParkEntities okchtaParkEntities = new okchtaParkEntities();

        private void exitToMenuStarhiWorkTwoBtn_Click(object sender, RoutedEventArgs e)
        {
            starshiWorkWindow starshiWorkWindow = new starshiWorkWindow();
            starshiWorkWindow.Show();
            this.Close();
        }
        // поиск услуги 
        private void searchServicesTB_SelectionChanged(object sender, RoutedEventArgs e)
        {
            model.okchtaParkEntities db = new model.okchtaParkEntities();

            string search = searchServicesTB.Text;

            if (searchServicesTB.Text != null)
            {
                var query = (from serv in db.Services
                             where serv.nameServices.ToString().Contains(search)
                             select serv).ToList();
                servicesDG.ItemsSource = query;
            }
        }

        private void addUslugiBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                addUslugiWindow addUslugiWindow = new addUslugiWindow();
                addUslugiWindow.Show();
                this.Close();
            }
            catch
            {
                MessageBox.Show("Ошибка!");
            }
        }
    }
}
